LUMIERE · Med Spa Business Templates
The Complete Med Spa Starter Bundle
==================================================

WHAT'S INSIDE
--------------------------------------------------
01 - Client Intake & Consultation Kit (7 pages, US Letter + A4)
02 - Client Treatment Record (4 pages, US Letter + A4)
03 - Aftercare & Client Education Cards (6 cards, US Letter + A4)
04 - Front Desk & Operations Kit (8 pages, US Letter + A4)
05 - Appointment Tracker (Excel .xlsx, 6 sheets + 2-page setup guide)
06 - Social Media Content Kit (14-page PDF + 12 Instagram-ready PNGs 1080x1080)
07 - Promotion & Loyalty Kit (7 pages, US Letter + A4)
08 - Complete Starter Bundle (all products merged into one 49-page PDF)

Plus: 8 Etsy-style preview images (Previews/) and a complete
Etsy listing kit with titles, 13 tags each, descriptions, pricing
and FAQs (Listing-Kit/etsy-listings.md).

HOW TO USE
--------------------------------------------------
1. Print the version matching your paper (US Letter 8.5x11" or A4)
   at "Actual size" (100%) - never "Fit to page".
2. To customize: upload any PDF to a free Canva account. All text
   is editable - change wording, colors, and drop in your clinic logo.
   Export as "PDF Print" for the sharpest result.
3. Cards: print on heavy cardstock and cut along the edges.
   Daily checklists: laminate and reuse with dry-erase markers.
4. Tracker: open the .xlsx in Excel or Google Sheets, replace the
   fictional sample data with your own.

IMPORTANT - PLEASE READ
--------------------------------------------------
- These are ADMINISTRATIVE templates for business organization only.
  They are not medical, legal, or compliance advice and are not
  HIPAA-compliant systems by themselves.
- Aftercare card instruction areas are fill-in placeholders. Add YOUR
  clinic's approved wording - this product does not provide medical advice.
- Have any clinical, consent, or treatment-related content reviewed by
  qualified professionals before use. Follow your local privacy rules
  for real client data.
- License: single business use. Print unlimited copies for your own
  clinic. Do not share, resell, or redistribute the files.

SELLING THIS BUNDLE (honest notes)
--------------------------------------------------
- These files are the PRODUCT. Selling them (e.g. on Etsy) is a
  separate step: it needs seller identity verification, payout setup
  (e.g. Payoneer for Pakistan), and listing/transaction fees
  (verify current Etsy fees before you start - they change).
- Sales are NOT guaranteed. Research demand, competitors, and pricing
  before investing in ads or a large catalogue. Start with one listing,
  measure views/favorites/conversion, then expand.

Fonts: Playfair Display + Inter (SIL Open Font License - free for
commercial use). Design system: warm ivory / charcoal / muted sage.

Built October 2026 · Lumiere Studio
