# LUMIÈRE · Med Spa Business Templates — Etsy Listing Kit

Pricing grounded in Oct 2026 competitor scan (single forms $3–$17, typical $6–$9; bundles ~$8).
These are test prices — validate with real listing data before launch.
Etsy fees (verify current): $0.20 listing + 6.5% transaction + ~3–4% payment processing.

---

## Listing 1 — Client Intake & Consultation Kit — $12

**Title:** Med Spa Client Intake Form Template | Esthetician Consultation Form | Printable Client Information Form | US Letter + A4 | Instant Download

**Tags:** med spa forms, client intake form, esthetician forms, consultation form, spa intake template, beauty salon forms, facial intake form, printable spa forms, medspa paperwork, salon client form, intake form template, aesthetic clinic forms, spa business forms

**Description:**
Welcome new clients like a premium clinic with the LUMIÈRE Client Intake & Consultation Kit — a 7-page administrative template set designed for med spas, estheticians, and aesthetic clinics.

WHAT'S INCLUDED (instant download):
- 7-page PDF in US Letter (8.5×11")
- 7-page PDF in A4
- Step-by-step instructions (print, customize in Canva, add your logo)

Pages: cover, client information form, consultation notes, client preferences, appointment summary, additional notes, instructions.

HOW IT WORKS: Purchase → download → print at "Actual size" (or upload to free Canva to edit text and add your logo) → use at your front desk.

PLEASE NOTE: Digital download only — no physical item ships. This kit covers administrative organization (contact details, preferences, visit notes). It does not include medical-history, consent, or treatment-specific forms. Have any clinical content reviewed by qualified professionals.

---

## Listing 2 — Client Treatment Record Template — $9

**Title:** Esthetician Treatment Record Form | Med Spa Client Visit Log | Printable Service Record Template | US Letter + A4 | Instant Download

**Tags:** treatment record form, esthetician forms, med spa forms, client record template, spa visit log, facial record form, salon record keeping, printable treatment log, beauty business forms, service record sheet, client chart template, medspa paperwork, spa forms bundle

**Description:**
Keep every visit organized with the LUMIÈRE Client Treatment Record — a 4-page administrative record system for med spas and estheticians.

WHAT'S INCLUDED: 4-page PDF in US Letter + 4-page PDF in A4 + instructions.
Pages: cover, visit record form (date, service category, admin notes, follow-up), multi-visit log table, instructions.

Administrative use only — not a clinical or legal record system. Follow your local record-keeping and privacy rules.

---

## Listing 3 — Aftercare & Client Education Cards — $8

**Title:** Med Spa Aftercare Cards Template | Printable Esthetician Instruction Cards | Spa Thank You Cards | Editable | Instant Download

**Tags:** aftercare cards, spa instruction cards, esthetician cards, med spa cards, printable thank you cards, appointment reminder cards, referral cards spa, beauty business cards, facial aftercare template, salon stationery, client education cards, spa marketing cards, esthetician printables

**Description:**
Six elegant printable cards (2 per page) that make your clinic look polished at every touchpoint: Thank You for Visiting, Next Appointment Reminder, After-Visit Care, How to Reach Us, Refer a Friend, and Review Us.

WHAT'S INCLUDED: 5-page PDF (US Letter + A4 versions) with 6 card designs + instructions. Print on cardstock and cut.

IMPORTANT: Instruction areas are fill-in placeholders — add YOUR clinic's approved wording. This product does not provide medical advice.

---

## Listing 4 — Front Desk & Operations Kit — $14

**Title:** Med Spa Operations Kit | Spa Opening Closing Checklist | Front Desk Forms Bundle | Printable Salon Checklists | Instant Download

**Tags:** spa operations kit, salon checklists, opening closing checklist, front desk forms, med spa business, spa daily checklist, cleaning log template, inventory checklist, salon operations, appointment prep checklist, spa task tracker, shift handover notes, beauty business forms

**Description:**
Run your front desk like clockwork. The 8-page LUMIÈRE Operations Kit includes: opening checklist, closing checklist, appointment preparation checklist, daily task tracker, inventory checklist, cleaning log, and shift handover notes.

WHAT'S INCLUDED: 8-page PDF in US Letter + A4 + instructions. Laminate the daily checklists and reuse with dry-erase markers.

Adapt sanitation/operations content to your local rules and professional guidance.

---

## Listing 5 — Client & Appointment Tracker Spreadsheet — $19

**Title:** Med Spa Appointment Tracker Spreadsheet | Esthetician Client Management | Google Sheets + Excel | Salon Booking Tracker | Instant Download

**Tags:** appointment tracker, spa booking spreadsheet, client management excel, esthetician planner, salon tracker template, google sheets scheduler, med spa organizer, beauty business spreadsheet, appointment book digital, client database template, salon admin template, follow up tracker, small business spreadsheet

**Description:**
A beautiful, easy-to-use spreadsheet that organizes your appointments, clients, services, and follow-ups — with an automatic dashboard.

WHAT'S INCLUDED: Excel (.xlsx, works in Google Sheets too) with 6 tabs — Instructions, Dashboard (auto KPIs), Appointments (with status dropdowns), Clients, Services, Follow-ups (due-date highlighting) — plus a 2-page PDF setup guide. Fictional sample data included; replace with your own in minutes.

PRIVACY NOTE: Assess your own software security and data-handling practices before storing real client information.

---

## Listing 6 — Social Media Content Kit (12 Templates) — $15

**Title:** Med Spa Instagram Templates | Esthetician Social Media Kit | 12 Editable Spa Post Templates | Canva Ready | Instant Download

**Tags:** med spa instagram, esthetician templates, spa social media kit, instagram post templates, beauty salon marketing, facial promo graphics, salon instagram posts, skincare templates, medspa marketing, editable canva templates, spa promotion graphics, beauty business branding, social media bundle

**Description:**
Twelve elegant, typographic Instagram templates in a consistent luxury-neutral style: Now Booking, New Service, Seasonal Offer, Client Love, Self-Care Reminder, Meet the Team, Booking Reminder, Holiday Hours, Referral Program, Skincare Tip, FAQ, and Quote.

WHAT'S INCLUDED: 12 high-res PNGs (1080×1080) + PDF reference + instructions. Edit text and colors in free Canva; replace bracketed placeholders with your details.

Avoid misleading claims in your final copy — "results vary" included where relevant.

---

## Listing 7 — Promotion & Loyalty Kit — $12

**Title:** Spa Loyalty Card Template | Med Spa Referral Cards | Printable Gift Certificate | Salon Promo Kit | Instant Download

**Tags:** spa loyalty cards, referral card template, gift certificate template, salon promo kit, printable reward cards, med spa marketing, esthetician referral, beauty salon flyer, customer loyalty template, spa gift voucher, seasonal promo flyer, thank you cards spa, small business marketing

**Description:**
Everything you need to turn happy clients into repeat clients: 8-up referral cards, 8-up loyalty stamp cards (10-stamp "Glow Rewards"), full-page gift certificate, seasonal promo flyer, thank-you card, and review-request card.

WHAT'S INCLUDED: 7-page PDF (US Letter + A4) + instructions. Print cards on heavy cardstock.

Set your own offer terms, expiry dates, and check local gift-card/promotion rules.

---

## Listing 8 — COMPLETE Med Spa Starter Bundle — $39 (reg. $89 value)

**Title:** Ultimate Med Spa Business Bundle | 40+ Pages | Intake Forms, Checklists, Tracker, Social Media Kit | Esthetician Starter Pack

**Tags:** med spa bundle, esthetician starter kit, spa business bundle, salon forms bundle, medspa paperwork pack, beauty business kit, spa operations bundle, client forms bundle, spa marketing bundle, esthetician business, salon starter pack, spa templates bundle, digital download bundle

**Description:**
The complete LUMIÈRE system — every template above in one coordinated bundle (40+ pages + spreadsheet + 12 social templates):

1. Client Intake & Consultation Kit (7 pages)
2. Client Treatment Record (4 pages)
3. Aftercare & Education Cards (6 cards)
4. Front Desk & Operations Kit (8 pages)
5. Appointment Tracker spreadsheet + guide
6. Social Media Content Kit (12 designs)
7. Promotion & Loyalty Kit (7 pages)

All in US Letter + A4, print-ready PDFs, one consistent luxury design, beginner instructions included. Buy the bundle and save over 55% vs. individual listings.

Same administrative-use and professional-review notes apply as in individual listings.

---

## FAQ (use on all listings)

**Is this a physical product?** No — instant digital download. Nothing ships.
**How do I edit it?** Upload the PDF to free Canva — all text is editable. Add your logo, change wording, export as PDF Print.
**What paper size?** Both US Letter and A4 included. Print at "Actual size" (100%).
**Can I share/resell the files?** No — single-business license. You may print unlimited copies for your own clinic.
**Do you offer refunds?** Due to the digital nature, all sales are final — please read the description carefully before purchase.
